#ifndef _SDRIVER_H_
#define _SDRIVER_H_

char SoundDriver_Init(long *freq);

#endif


